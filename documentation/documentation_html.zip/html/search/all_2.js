var searchData=
[
  ['back_5ftransform_5fmatrix_23',['back_transform_matrix',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Preprocessed__Simulator.html#a108a4cd0860345eddaed2682800ffa40',1,'ep_bolfi::optimization::EP_BOLFI::Preprocessed_Simulator']]],
  ['bode_5fplot_24',['bode_plot',['../namespaceep__bolfi_1_1utility_1_1visualization.html#abd39be2ba12fb1eb55b1db645c0ea301',1,'ep_bolfi::utility::visualization']]],
  ['boundaries_5fin_5fdeviations_25',['boundaries_in_deviations',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1EP__BOLFI.html#aba5e962496c734aef859732e2c424fa3',1,'ep_bolfi::optimization::EP_BOLFI::EP_BOLFI']]]
];
