var searchData=
[
  ['k_5fb_628',['k_B',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#a6d64fef22d6ebfc648414dc7281037c1',1,'ep_bolfi::models::standard_parameters']]]
];
