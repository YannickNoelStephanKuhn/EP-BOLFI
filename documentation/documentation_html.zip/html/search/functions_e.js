var searchData=
[
  ['read_5fchannels_5ffrom_5fmeasurement_5fsystem',['read_channels_from_measurement_system',['../namespacePython_1_1utility_1_1read__csv__datasets.html#a5525bd25beea0ed6bc032ca991b0291b',1,'Python::utility::read_csv_datasets']]],
  ['read_5fvoltages_5ffrom_5fcsv',['read_voltages_from_csv',['../namespacePython_1_1utility_1_1read__csv__datasets.html#a11d449c5dfcae7619cc5b94a05b0cd8e',1,'Python::utility::read_csv_datasets']]],
  ['return_5fsimulator',['return_simulator',['../namespacePython_1_1optimization_1_1EP__BOLFI.html#a4b90e5a875817da9a4098bcd118a4c7a',1,'Python::optimization::EP_BOLFI']]]
];
