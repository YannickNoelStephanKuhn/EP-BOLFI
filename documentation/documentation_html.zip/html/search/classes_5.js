var searchData=
[
  ['ocv_5ffit_5fresult_385',['OCV_fit_result',['../classep__bolfi_1_1utility_1_1fitting__functions_1_1OCV__fit__result.html',1,'ep_bolfi::utility::fitting_functions']]],
  ['optimizer_5fstate_386',['Optimizer_State',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Optimizer__State.html',1,'ep_bolfi::optimization::EP_BOLFI']]]
];
