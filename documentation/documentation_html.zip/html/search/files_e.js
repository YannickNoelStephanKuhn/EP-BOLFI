var searchData=
[
  ['thick_5felectrodes_2epy',['thick_electrodes.py',['../thick__electrodes_8py.html',1,'']]]
];
