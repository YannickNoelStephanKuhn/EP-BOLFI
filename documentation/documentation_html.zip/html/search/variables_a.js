var searchData=
[
  ['mcmc_5fchains_644',['mcmc_chains',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Optimizer__State.html#a50325273c1616f4a29f626a64abf9dce',1,'ep_bolfi::optimization::EP_BOLFI::Optimizer_State']]],
  ['model_5fresampling_5fincrease_645',['model_resampling_increase',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Optimizer__State.html#ae3026643e3513fa54ea31838c875575e',1,'ep_bolfi::optimization::EP_BOLFI::Optimizer_State']]]
];
