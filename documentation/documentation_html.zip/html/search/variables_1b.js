var searchData=
[
  ['κₑ_5fhat_744',['κₑ_hat',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#a9f5c02026597acf66216a45ef5fb3cbb',1,'ep_bolfi::models::standard_parameters']]],
  ['κₑ_5ftyp_745',['κₑ_typ',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#ab7f89d9112711a53da862ec2b801aabd',1,'ep_bolfi::models::standard_parameters']]]
];
