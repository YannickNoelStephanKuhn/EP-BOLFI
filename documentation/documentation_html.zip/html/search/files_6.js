var searchData=
[
  ['solversetup_2epy_410',['solversetup.py',['../solversetup_8py.html',1,'']]],
  ['standard_5fparameters_2epy_411',['standard_parameters.py',['../standard__parameters_8py.html',1,'']]]
];
