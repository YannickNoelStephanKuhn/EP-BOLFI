var searchData=
[
  ['n',['n',['../namespacePython_1_1watershed.html#a56ffb66b1944390d157df611da9088d5',1,'Python::watershed']]],
  ['n_5fcells',['n_cells',['../namespacePython_1_1models_1_1standard__parameters.html#a44122e00d98be9ce3a4487cce25b96a0',1,'Python::models::standard_parameters']]],
  ['n_5felectrodes_5fparallel',['n_electrodes_parallel',['../namespacePython_1_1models_1_1standard__parameters.html#a1c1510594b628dde0602f4141f0f8d5f',1,'Python::models::standard_parameters']]],
  ['name',['NAME',['../classPython_1_1particle__identification_1_1particles_1_1ParticlesConfig.html#a8a89d9b704f9b40bda7e1c72023735c0',1,'Python::particle_identification::particles::ParticlesConfig']]],
  ['name_5fof_5fdis_5fcharge_5ffeatures',['name_of_dis_charge_features',['../namespacePython_1_1parameters_1_1estimation_1_1discharge__thick__electrodes.html#a49271fd350cda22ac5032d8d55994f60',1,'Python::parameters::estimation::discharge_thick_electrodes']]],
  ['name_5fof_5fgitt_5ffeatures',['name_of_gitt_features',['../namespacePython_1_1parameters_1_1estimation_1_1gitt__timo.html#ac8a358aa72ccd3d2bce663009178168c',1,'Python::parameters::estimation::gitt_timo']]],
  ['ncols',['ncols',['../namespacePython_1_1estimate__ocv__from__cc__cv.html#a488f195770c21511c16c0de2b6dbe1d3',1,'Python.estimate_ocv_from_cc_cv.ncols()'],['../namespacePython_1_1ocv__visualization.html#aff96883b25cd907d89ccbb13cebe3a43',1,'Python.ocv_visualization.ncols()'],['../namespacePython_1_1watershed.html#a94704d14089ff3d5fb30d130750732d1',1,'Python.watershed.ncols()']]],
  ['neg_5fint',['neg_int',['../namespacePython_1_1optimization_1_1run__estimation.html#afa806804c181d2df16f2e28d7938cc3d',1,'Python::optimization::run_estimation']]],
  ['new_5fcopy',['new_copy',['../classPython_1_1models_1_1DFN_1_1DFN.html#a96ea4957e7948cbdae12e02265b0024b',1,'Python.models.DFN.DFN.new_copy()'],['../classPython_1_1models_1_1SPM_1_1SPM.html#ace3d1a7d759d0410ed4135fbddb09297',1,'Python.models.SPM.SPM.new_copy()'],['../classPython_1_1models_1_1SPMe_1_1SPMe.html#a4780479abb45c53383c6c360dee5da8b',1,'Python.models.SPMe.SPMe.new_copy()']]],
  ['nop',['nop',['../namespacePython_1_1analytic__impedance__visualization.html#a1b4a0809a3985011701527ff9874b3ab',1,'Python::analytic_impedance_visualization']]],
  ['nrows',['nrows',['../namespacePython_1_1estimate__ocv__from__cc__cv.html#a43a805d14ce80120a874be289c51f156',1,'Python.estimate_ocv_from_cc_cv.nrows()'],['../namespacePython_1_1watershed.html#a3c388ce19b4e475c7c1b50c0e3513e76',1,'Python.watershed.nrows()']]],
  ['num_5fclasses',['NUM_CLASSES',['../classPython_1_1particle__identification_1_1particles_1_1ParticlesConfig.html#a130e169af23b4a810228318a77e049f9',1,'Python::particle_identification::particles::ParticlesConfig']]]
];
