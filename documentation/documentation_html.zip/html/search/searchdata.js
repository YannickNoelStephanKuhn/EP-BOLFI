var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxyzΔαβγεκπστω",
  1: "acdhips",
  2: "mopu",
  3: "_abcdefgimoprstvw",
  4: "_abcdefgilmnoprstuvwzκ",
  5: "abcdefghiklmnopqrstuvwxyzΔαβγεκπστω"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables"
};

