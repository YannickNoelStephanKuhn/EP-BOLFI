var searchData=
[
  ['n_5fcells_646',['n_cells',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#aee474f85ec3c565cea57a7d3d3243c97',1,'ep_bolfi::models::standard_parameters']]],
  ['n_5felectrodes_5fparallel_647',['n_electrodes_parallel',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#a9fc6fac6ec597239d587a46df4ebb1c6',1,'ep_bolfi::models::standard_parameters']]],
  ['norm_5ffactor_648',['norm_factor',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Preprocessed__Simulator.html#a9c1895cf7a9470a520df34200beee508',1,'ep_bolfi::optimization::EP_BOLFI::Preprocessed_Simulator']]],
  ['normed_5fmeans_649',['normed_means',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Preprocessed__Simulator.html#aa76d87665d152d264a36f7665b92f7eb',1,'ep_bolfi::optimization::EP_BOLFI::Preprocessed_Simulator']]]
];
