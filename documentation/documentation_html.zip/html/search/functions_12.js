var searchData=
[
  ['verbose_5fspline_5fparameterization',['verbose_spline_parameterization',['../namespacePython_1_1utility_1_1fitting__functions.html#ae6e85434a93225bc2a3afe21afcc9339',1,'Python::utility::fitting_functions']]]
];
