var searchData=
[
  ['verbose_5fspline_5fparameterization_548',['verbose_spline_parameterization',['../namespaceep__bolfi_1_1utility_1_1fitting__functions.html#ab92be3ef5a06d8c0c3b576a79b5123ce',1,'ep_bolfi::utility::fitting_functions']]],
  ['visualize_5fcorrelation_549',['visualize_correlation',['../namespaceep__bolfi_1_1utility_1_1visualization.html#a4c27b186ccc64e458136401ab161e3cf',1,'ep_bolfi::utility::visualization']]],
  ['visualize_5fparameter_5fdistribution_550',['visualize_parameter_distribution',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1EP__BOLFI.html#a8d358c7f9f8e0b1398f138ad28dec786',1,'ep_bolfi::optimization::EP_BOLFI::EP_BOLFI']]]
];
