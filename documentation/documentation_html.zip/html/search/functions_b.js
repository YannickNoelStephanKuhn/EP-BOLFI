var searchData=
[
  ['name_5fof_5fdis_5fcharge_5ffeatures',['name_of_dis_charge_features',['../namespacePython_1_1parameters_1_1estimation_1_1discharge__thick__electrodes.html#a49271fd350cda22ac5032d8d55994f60',1,'Python::parameters::estimation::discharge_thick_electrodes']]],
  ['name_5fof_5fgitt_5ffeatures',['name_of_gitt_features',['../namespacePython_1_1parameters_1_1estimation_1_1gitt__timo.html#ac8a358aa72ccd3d2bce663009178168c',1,'Python::parameters::estimation::gitt_timo']]],
  ['neg_5fint',['neg_int',['../namespacePython_1_1optimization_1_1run__estimation.html#afa806804c181d2df16f2e28d7938cc3d',1,'Python::optimization::run_estimation']]],
  ['new_5fcopy',['new_copy',['../classPython_1_1models_1_1DFN_1_1DFN.html#a96ea4957e7948cbdae12e02265b0024b',1,'Python.models.DFN.DFN.new_copy()'],['../classPython_1_1models_1_1SPM_1_1SPM.html#ace3d1a7d759d0410ed4135fbddb09297',1,'Python.models.SPM.SPM.new_copy()'],['../classPython_1_1models_1_1SPMe_1_1SPMe.html#a4780479abb45c53383c6c360dee5da8b',1,'Python.models.SPMe.SPMe.new_copy()']]]
];
