var searchData=
[
  ['new_5fcopy_490',['new_copy',['../classep__bolfi_1_1models_1_1electrolyte_1_1Electrolyte.html#a92ead0f49af6503b33743a20822f3730',1,'ep_bolfi::models::electrolyte::Electrolyte']]],
  ['nyquist_5fplot_491',['nyquist_plot',['../namespaceep__bolfi_1_1utility_1_1visualization.html#a6339f95f5c841e9240873563ca04840e',1,'ep_bolfi::utility::visualization']]]
];
