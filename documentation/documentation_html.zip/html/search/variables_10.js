var searchData=
[
  ['sampling_5ffrom_5fzero_684',['sampling_from_zero',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Optimizer__State.html#a41685a4d9ad38674939d7e848d4208e6',1,'ep_bolfi::optimization::EP_BOLFI::Optimizer_State']]],
  ['simulator_685',['simulator',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Preprocessed__Simulator.html#a7ff0524715be26069ccc7129459b4d6a',1,'ep_bolfi::optimization::EP_BOLFI::Preprocessed_Simulator']]],
  ['simulator_5findex_5fby_5ffeature_686',['simulator_index_by_feature',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1EP__BOLFI.html#af008b8a2b9881df31f18b1d5caf78fec',1,'ep_bolfi::optimization::EP_BOLFI::EP_BOLFI']]],
  ['simulators_687',['simulators',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1EP__BOLFI.html#a27d18d260c2fc9889bfb407b82e92802',1,'ep_bolfi::optimization::EP_BOLFI::EP_BOLFI']]],
  ['soc_688',['SOC',['../classep__bolfi_1_1utility_1_1fitting__functions_1_1OCV__fit__result.html#a20ccc033b9c8f7e9e498541a1304bce3',1,'ep_bolfi::utility::fitting_functions::OCV_fit_result']]],
  ['soc_5foffset_689',['SOC_offset',['../classep__bolfi_1_1utility_1_1fitting__functions_1_1OCV__fit__result.html#a428633d2b470a09160072aaac6d68db3',1,'ep_bolfi::utility::fitting_functions::OCV_fit_result']]],
  ['soc_5frange_690',['SOC_range',['../classep__bolfi_1_1utility_1_1fitting__functions_1_1OCV__fit__result.html#a831f7fde0d390a208e68539423c28359',1,'ep_bolfi::utility::fitting_functions::OCV_fit_result']]],
  ['soc_5fscale_691',['SOC_scale',['../classep__bolfi_1_1utility_1_1fitting__functions_1_1OCV__fit__result.html#ae62219d189d542117ebfab83ee0f90f0',1,'ep_bolfi::utility::fitting_functions::OCV_fit_result']]],
  ['spline_5finterpolation_5fcoefficients_692',['spline_interpolation_coefficients',['../classep__bolfi_1_1utility_1_1fitting__functions_1_1OCV__fit__result.html#a9093ac893dedb18745dbbd50a7d5177c',1,'ep_bolfi::utility::fitting_functions::OCV_fit_result']]],
  ['spline_5finterpolation_5fknots_693',['spline_interpolation_knots',['../classep__bolfi_1_1utility_1_1fitting__functions_1_1OCV__fit__result.html#a7945bf17406be5a7285dd14e8692cf48',1,'ep_bolfi::utility::fitting_functions::OCV_fit_result']]],
  ['sub_5findex_5fby_5ffeature_694',['sub_index_by_feature',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1EP__BOLFI.html#a19d6f0dacbf92313ef536681a449f970',1,'ep_bolfi::optimization::EP_BOLFI::EP_BOLFI']]]
];
