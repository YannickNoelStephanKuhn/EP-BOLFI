var searchData=
[
  ['undo_5ftransformation_545',['undo_transformation',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Preprocessed__Simulator.html#a44dbc5e43596f86dcc5a3025556e02f5',1,'ep_bolfi::optimization::EP_BOLFI::Preprocessed_Simulator']]],
  ['update_5flegend_546',['update_legend',['../namespaceep__bolfi_1_1utility_1_1visualization.html#a6da2edd92c632d22e78a98bd81592ec9',1,'ep_bolfi::utility::visualization']]],
  ['update_5flimits_547',['update_limits',['../namespaceep__bolfi_1_1utility_1_1visualization.html#a8da797c9fe6ba461ffb5ac28c6e1a511',1,'ep_bolfi::utility::visualization']]]
];
