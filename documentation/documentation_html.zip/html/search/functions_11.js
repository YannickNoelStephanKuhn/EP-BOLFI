var searchData=
[
  ['update_5flegend',['update_legend',['../namespacePython_1_1utility_1_1visualization.html#a6fd9948676d0ab0e5ffa42265fe9f1ca',1,'Python::utility::visualization']]],
  ['update_5flimits',['update_limits',['../namespacePython_1_1utility_1_1visualization.html#a186f55916a9898cf47724de0087b2d04',1,'Python::utility::visualization']]]
];
