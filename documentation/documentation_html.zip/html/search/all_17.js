var searchData=
[
  ['xlabel',['xlabel',['../namespacePython_1_1dis__charge__visualisation.html#a0806ac49722ea04f5384c675f6306c28',1,'Python.dis_charge_visualisation.xlabel()'],['../namespacePython_1_1gitt__visualization.html#a54339dcffb56cb6779c7a6cb0fd1bb69',1,'Python.gitt_visualization.xlabel()']]]
];
