var searchData=
[
  ['solversetup_2epy',['solversetup.py',['../solversetup_8py.html',1,'']]],
  ['spm_2epy',['SPM.py',['../SPM_8py.html',1,'']]],
  ['spme_2epy',['SPMe.py',['../SPMe_8py.html',1,'']]],
  ['standard_5fparameters_2epy',['standard_parameters.py',['../standard__parameters_8py.html',1,'']]]
];
