var searchData=
[
  ['r_669',['r',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Preprocessed__Simulator.html#add3b95169b212345d94905a739db0620',1,'ep_bolfi.optimization.EP_BOLFI.Preprocessed_Simulator.r()'],['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1EP__BOLFI.html#a4e9956f3622f6890f92c1230f7dad8e2',1,'ep_bolfi.optimization.EP_BOLFI.EP_BOLFI.r()']]],
  ['r_670',['R',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#a86d2fafefe2a957d93e33dbeca1f9e55',1,'ep_bolfi::models::standard_parameters']]],
  ['r_5fbar_5fcₑₙ_5f1_671',['R_bar_cₑₙ_1',['../classep__bolfi_1_1models_1_1assess__effective__parameters_1_1Effective__Parameters.html#a9f72b0d910bd53f3890eb537eb0dc176',1,'ep_bolfi::models::assess_effective_parameters::Effective_Parameters']]],
  ['r_5fbar_5fcₑₚ_5f1_672',['R_bar_cₑₚ_1',['../classep__bolfi_1_1models_1_1assess__effective__parameters_1_1Effective__Parameters.html#a765ad8651650406c44b91bf153f458f2',1,'ep_bolfi::models::assess_effective_parameters::Effective_Parameters']]],
  ['r_5fbar_5fφₛₙ_5f1_673',['R_bar_φₛₙ_1',['../classep__bolfi_1_1models_1_1assess__effective__parameters_1_1Effective__Parameters.html#ae84a78e772e50404bada31e0d269d51f',1,'ep_bolfi::models::assess_effective_parameters::Effective_Parameters']]],
  ['r_5fbar_5fφₛₚ_5f1_674',['R_bar_φₛₚ_1',['../classep__bolfi_1_1models_1_1assess__effective__parameters_1_1Effective__Parameters.html#a9b311f778bb0d1b1b6e8621ec39453a6',1,'ep_bolfi::models::assess_effective_parameters::Effective_Parameters']]],
  ['r_5fcₑ_5f0_5f1_675',['R_cₑ_0_1',['../classep__bolfi_1_1models_1_1assess__effective__parameters_1_1Effective__Parameters.html#a6aff5eb4f1687060d0292bfb004d65e0',1,'ep_bolfi::models::assess_effective_parameters::Effective_Parameters']]],
  ['r_5ffeatures_676',['r_features',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1EP__BOLFI.html#a43d44296ae8a5cd4561b40a0653fbc01',1,'ep_bolfi::optimization::EP_BOLFI::EP_BOLFI']]],
  ['real_5fimpedances_677',['real_impedances',['../classep__bolfi_1_1utility_1_1dataset__formatting_1_1Impedance__Measurement.html#aa3e87331b81e2f95dc6b1faefb3a2bca',1,'ep_bolfi::utility::dataset_formatting::Impedance_Measurement']]],
  ['resampling_678',['resampling',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Optimizer__State.html#a365fdb37ca79824478bb54bd3e8223fc',1,'ep_bolfi::optimization::EP_BOLFI::Optimizer_State']]],
  ['rₑ_679',['Rₑ',['../classep__bolfi_1_1models_1_1assess__effective__parameters_1_1Effective__Parameters.html#ac7731ac8abb84101ce79f5534f9fc0e2',1,'ep_bolfi::models::assess_effective_parameters::Effective_Parameters']]],
  ['rₙ_680',['Rₙ',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#acf9db07aab555fe7d3fa9aa94262bc9b',1,'ep_bolfi::models::standard_parameters']]],
  ['rₙₛ_681',['Rₙₛ',['../classep__bolfi_1_1models_1_1assess__effective__parameters_1_1Effective__Parameters.html#a977a218a5276217f21dfcb8e349cd38c',1,'ep_bolfi::models::assess_effective_parameters::Effective_Parameters']]],
  ['rₚ_682',['Rₚ',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#aabc23708589f33e1531daa92f7f857b7',1,'ep_bolfi::models::standard_parameters']]],
  ['rₚₛ_683',['Rₚₛ',['../classep__bolfi_1_1models_1_1assess__effective__parameters_1_1Effective__Parameters.html#aa04ec5c9c5f4d423dfdf254a55c0ab97',1,'ep_bolfi::models::assess_effective_parameters::Effective_Parameters']]]
];
