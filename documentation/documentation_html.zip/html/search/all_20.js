var searchData=
[
  ['π',['π',['../namespacePython_1_1parameters_1_1models_1_1basf__samsung.html#aa916a2f7b3eb59aeeec2483f23692a16',1,'Python.parameters.models.basf_samsung.π()'],['../namespacePython_1_1watershed.html#a3f758aa9b177d7b3a36ebf4013bc7435',1,'Python.watershed.π()']]]
];
