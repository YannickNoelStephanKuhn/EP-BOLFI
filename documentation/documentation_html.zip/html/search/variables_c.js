var searchData=
[
  ['n',['n',['../namespacePython_1_1watershed.html#a56ffb66b1944390d157df611da9088d5',1,'Python::watershed']]],
  ['n_5fcells',['n_cells',['../namespacePython_1_1models_1_1standard__parameters.html#a44122e00d98be9ce3a4487cce25b96a0',1,'Python::models::standard_parameters']]],
  ['n_5felectrodes_5fparallel',['n_electrodes_parallel',['../namespacePython_1_1models_1_1standard__parameters.html#a1c1510594b628dde0602f4141f0f8d5f',1,'Python::models::standard_parameters']]],
  ['name',['NAME',['../classPython_1_1particle__identification_1_1particles_1_1ParticlesConfig.html#a8a89d9b704f9b40bda7e1c72023735c0',1,'Python::particle_identification::particles::ParticlesConfig']]],
  ['ncols',['ncols',['../namespacePython_1_1estimate__ocv__from__cc__cv.html#a488f195770c21511c16c0de2b6dbe1d3',1,'Python.estimate_ocv_from_cc_cv.ncols()'],['../namespacePython_1_1ocv__visualization.html#aff96883b25cd907d89ccbb13cebe3a43',1,'Python.ocv_visualization.ncols()'],['../namespacePython_1_1watershed.html#a94704d14089ff3d5fb30d130750732d1',1,'Python.watershed.ncols()']]],
  ['nop',['nop',['../namespacePython_1_1analytic__impedance__visualization.html#a1b4a0809a3985011701527ff9874b3ab',1,'Python::analytic_impedance_visualization']]],
  ['nrows',['nrows',['../namespacePython_1_1estimate__ocv__from__cc__cv.html#a43a805d14ce80120a874be289c51f156',1,'Python.estimate_ocv_from_cc_cv.nrows()'],['../namespacePython_1_1watershed.html#a3c388ce19b4e475c7c1b50c0e3513e76',1,'Python.watershed.nrows()']]],
  ['num_5fclasses',['NUM_CLASSES',['../classPython_1_1particle__identification_1_1particles_1_1ParticlesConfig.html#a130e169af23b4a810228318a77e049f9',1,'Python::particle_identification::particles::ParticlesConfig']]]
];
