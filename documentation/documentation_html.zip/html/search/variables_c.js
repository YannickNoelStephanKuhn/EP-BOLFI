var searchData=
[
  ['ocv_650',['OCV',['../classep__bolfi_1_1utility_1_1fitting__functions_1_1OCV__fit__result.html#ac9a8facdd759587e6085d8d13aad1245',1,'ep_bolfi::utility::fitting_functions::OCV_fit_result']]],
  ['ocvₙ_5fref_651',['OCVₙ_ref',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#a381cae43d5e469e517dd40c2acc60d3a',1,'ep_bolfi::models::standard_parameters']]],
  ['ocvₚ_5fref_652',['OCVₚ_ref',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#a99096078378b12430a2a7ad17139f9dc',1,'ep_bolfi::models::standard_parameters']]],
  ['optimize_5fresult_653',['optimize_result',['../classep__bolfi_1_1utility_1_1fitting__functions_1_1OCV__fit__result.html#afb5967830a6c56fc8c7ee7a0e8b93f60',1,'ep_bolfi::utility::fitting_functions::OCV_fit_result']]],
  ['options_654',['options',['../classep__bolfi_1_1models_1_1electrolyte_1_1Electrolyte.html#ab4d7f33207fb4ea4c39a3ecaa3cc76aa',1,'ep_bolfi::models::electrolyte::Electrolyte']]],
  ['order_5fof_5factions_655',['order_of_actions',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Optimizer__State.html#ac6b6d88c8bfc783d9f94c9d8d22b3925',1,'ep_bolfi::optimization::EP_BOLFI::Optimizer_State']]],
  ['other_5fcolumns_656',['other_columns',['../classep__bolfi_1_1utility_1_1dataset__formatting_1_1Cycling__Information.html#ab977541129b5fc31c224441f19c5e81e',1,'ep_bolfi.utility.dataset_formatting.Cycling_Information.other_columns()'],['../classep__bolfi_1_1utility_1_1dataset__formatting_1_1Impedance__Measurement.html#a59c085f91963525a1f2cdd7a9d08aa84',1,'ep_bolfi.utility.dataset_formatting.Impedance_Measurement.other_columns()']]],
  ['output_5fdim_657',['output_dim',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Preprocessed__Simulator.html#a3614ce119f32c3ee7f7783320d3fbca5',1,'ep_bolfi.optimization.EP_BOLFI.Preprocessed_Simulator.output_dim()'],['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1EP__BOLFI.html#a6a8d75d3b71fac760c4d84952d475636',1,'ep_bolfi.optimization.EP_BOLFI.EP_BOLFI.output_dim()']]]
];
