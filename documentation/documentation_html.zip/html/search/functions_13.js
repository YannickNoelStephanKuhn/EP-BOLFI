var searchData=
[
  ['κₑ_551',['κₑ',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#abb53888b6b9f18a631e26e85d509b188',1,'ep_bolfi::models::standard_parameters']]],
  ['κₑ_5fdim_552',['κₑ_dim',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#aa40e99ad13169b43b177df94edd69594',1,'ep_bolfi::models::standard_parameters']]]
];
