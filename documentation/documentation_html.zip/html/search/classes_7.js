var searchData=
[
  ['static_5finformation_388',['Static_Information',['../classep__bolfi_1_1utility_1_1dataset__formatting_1_1Static__Information.html',1,'ep_bolfi::utility::dataset_formatting']]],
  ['substitutiondict_389',['SubstitutionDict',['../classep__bolfi_1_1utility_1_1preprocessing_1_1SubstitutionDict.html',1,'ep_bolfi::utility::preprocessing']]]
];
