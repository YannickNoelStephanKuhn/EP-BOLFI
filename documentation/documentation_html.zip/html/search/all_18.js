var searchData=
[
  ['ylabel',['ylabel',['../namespacePython_1_1dis__charge__visualisation.html#a0b51057e62cc304281c57ab7f91642c4',1,'Python.dis_charge_visualisation.ylabel()'],['../namespacePython_1_1gitt__visualization.html#a1ee73de5af5a91230a2e3a6aec819041',1,'Python.gitt_visualization.ylabel()']]]
];
