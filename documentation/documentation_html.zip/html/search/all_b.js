var searchData=
[
  ['make_5fsegments_190',['make_segments',['../namespaceep__bolfi_1_1utility_1_1visualization.html#a46f75754c65db88e70fe5c067ce0085a',1,'ep_bolfi::utility::visualization']]],
  ['mcmc_5fchains_191',['mcmc_chains',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Optimizer__State.html#a50325273c1616f4a29f626a64abf9dce',1,'ep_bolfi::optimization::EP_BOLFI::Optimizer_State']]],
  ['measurement_192',['Measurement',['../classep__bolfi_1_1utility_1_1dataset__formatting_1_1Measurement.html',1,'ep_bolfi::utility::dataset_formatting']]],
  ['model_5fresampling_5fincrease_193',['model_resampling_increase',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Optimizer__State.html#ae3026643e3513fa54ea31838c875575e',1,'ep_bolfi::optimization::EP_BOLFI::Optimizer_State']]]
];
