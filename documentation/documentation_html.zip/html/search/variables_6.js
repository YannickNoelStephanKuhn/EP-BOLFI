var searchData=
[
  ['gpu_5fcount',['GPU_COUNT',['../classPython_1_1particle__identification_1_1particles_1_1ParticlesConfig.html#ad1edfb9d750d1269922a85e714c80d7c',1,'Python.particle_identification.particles.ParticlesConfig.GPU_COUNT()'],['../classPython_1_1particle__identification_1_1particles_1_1InferenceConfig.html#af43be76f05fc1621744d7ae3252af181',1,'Python.particle_identification.particles.InferenceConfig.GPU_COUNT()']]],
  ['grayscale',['grayscale',['../namespacePython_1_1watershed.html#afd6e712d4570bc0f6288dc4733d48c2d',1,'Python::watershed']]]
];
