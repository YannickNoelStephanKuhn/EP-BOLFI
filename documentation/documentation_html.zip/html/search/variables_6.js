var searchData=
[
  ['gelman_5frubin_5fthreshold_610',['gelman_rubin_threshold',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Optimizer__State.html#a01cad0969d665208136fc471dc182e36',1,'ep_bolfi::optimization::EP_BOLFI::Optimizer_State']]]
];
