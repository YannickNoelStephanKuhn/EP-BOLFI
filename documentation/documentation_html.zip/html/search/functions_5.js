var searchData=
[
  ['expectation_5fpropagation',['expectation_propagation',['../namespacePython_1_1optimization_1_1EP__BOLFI.html#ab6b9a5e556fe9cf871d7400343970a48',1,'Python::optimization::EP_BOLFI']]]
];
