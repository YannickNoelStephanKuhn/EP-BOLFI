var searchData=
[
  ['q',['Q',['../namespacePython_1_1models_1_1standard__parameters.html#a7d872c31e6baf95989903c59d64aa3bf',1,'Python::models::standard_parameters']]],
  ['qₑ',['qₑ',['../namespacePython_1_1models_1_1standard__parameters.html#acfde5fecc9ff0d875c1f0b64edecd428',1,'Python::models::standard_parameters']]]
];
