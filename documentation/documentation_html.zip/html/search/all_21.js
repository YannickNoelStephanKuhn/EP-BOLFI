var searchData=
[
  ['σₙ',['σₙ',['../namespacePython_1_1models_1_1standard__parameters.html#a45cc0076d1f56b98fb03906e280757d1',1,'Python::models::standard_parameters']]],
  ['σₙ_5fdim',['σₙ_dim',['../namespacePython_1_1models_1_1standard__parameters.html#acdd15f1747091eaa4498b2a9423c5207',1,'Python::models::standard_parameters']]],
  ['σₚ',['σₚ',['../namespacePython_1_1models_1_1standard__parameters.html#ac55b2f54a8033fd18e077004d6fdaa05',1,'Python::models::standard_parameters']]],
  ['σₚ_5fdim',['σₚ_dim',['../namespacePython_1_1models_1_1standard__parameters.html#ab18cea15e9885986360be556bef24c9e',1,'Python::models::standard_parameters']]]
];
