var searchData=
[
  ['bode_5fplot_425',['bode_plot',['../namespaceep__bolfi_1_1utility_1_1visualization.html#abd39be2ba12fb1eb55b1db645c0ea301',1,'ep_bolfi::utility::visualization']]]
];
