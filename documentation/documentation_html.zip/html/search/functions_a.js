var searchData=
[
  ['make_5fsegments_489',['make_segments',['../namespaceep__bolfi_1_1utility_1_1visualization.html#a46f75754c65db88e70fe5c067ce0085a',1,'ep_bolfi::utility::visualization']]]
];
