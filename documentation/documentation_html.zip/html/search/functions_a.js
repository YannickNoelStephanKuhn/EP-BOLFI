var searchData=
[
  ['make_5fsegments',['make_segments',['../namespacePython_1_1utility_1_1visualization.html#a61572a58b25534effda23ba4dd5cb979',1,'Python::utility::visualization']]]
];
