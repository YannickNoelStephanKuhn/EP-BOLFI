var searchData=
[
  ['ndarrayencoder_384',['NDArrayEncoder',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1NDArrayEncoder.html',1,'ep_bolfi.optimization.EP_BOLFI.NDArrayEncoder'],['../classep__bolfi_1_1utility_1_1fitting__functions_1_1NDArrayEncoder.html',1,'ep_bolfi.utility.fitting_functions.NDArrayEncoder']]]
];
