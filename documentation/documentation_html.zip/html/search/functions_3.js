var searchData=
[
  ['calculate_5fboth_5fsoc_5ffrom_5focv_426',['calculate_both_SOC_from_OCV',['../namespaceep__bolfi_1_1utility_1_1preprocessing.html#abfe561a2c8ce16db041b5285838f7ffd',1,'ep_bolfi::utility::preprocessing']]],
  ['calculate_5fdesired_5fvoltage_427',['calculate_desired_voltage',['../namespaceep__bolfi_1_1utility_1_1preprocessing.html#ad2d20d813eb595343b6c54f7b7b26950',1,'ep_bolfi::utility::preprocessing']]],
  ['calculate_5fmeans_5fand_5fstandard_5fdeviations_428',['calculate_means_and_standard_deviations',['../namespaceep__bolfi_1_1utility_1_1preprocessing.html#a9883b383f05d134bf875ad0909f49613',1,'ep_bolfi::utility::preprocessing']]],
  ['calculate_5fnext_5fstep_429',['calculate_next_step',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Optimizer__State.html#a696d9f407ff62b1e3a5f411fee592460',1,'ep_bolfi::optimization::EP_BOLFI::Optimizer_State']]],
  ['calculate_5fsoc_430',['calculate_SOC',['../namespaceep__bolfi_1_1utility_1_1preprocessing.html#a064b823e83e5f7960371815aebec948b',1,'ep_bolfi::utility::preprocessing']]],
  ['capacity_431',['capacity',['../namespaceep__bolfi_1_1utility_1_1preprocessing.html#a3334f258356c7866e2f62d2bdf4e6540',1,'ep_bolfi::utility::preprocessing']]],
  ['cc_5fcv_5fvisualization_432',['cc_cv_visualization',['../namespaceep__bolfi_1_1utility_1_1visualization.html#a8aca9fa884be1f7a39bc60cafed9ddf0',1,'ep_bolfi::utility::visualization']]],
  ['colorline_433',['colorline',['../namespaceep__bolfi_1_1utility_1_1visualization.html#a3f16fd7a46c3f32e5f564266d362a802',1,'ep_bolfi::utility::visualization']]],
  ['combine_5fparameters_5fto_5ftry_434',['combine_parameters_to_try',['../namespaceep__bolfi_1_1optimization_1_1EP__BOLFI.html#a59c7d7e054f6839568c85d34ccdd3c63',1,'ep_bolfi.optimization.EP_BOLFI.combine_parameters_to_try()'],['../namespaceep__bolfi_1_1utility_1_1preprocessing.html#ac53f09383d818a253b5bdc4def8f904a',1,'ep_bolfi.utility.preprocessing.combine_parameters_to_try()']]],
  ['complex_5fimpedances_435',['complex_impedances',['../classep__bolfi_1_1utility_1_1dataset__formatting_1_1Impedance__Measurement.html#a9ff479060c75e8d42afa248255b73380',1,'ep_bolfi::utility::dataset_formatting::Impedance_Measurement']]],
  ['convert_5fnone_5fnotation_5fto_5fslicing_436',['convert_none_notation_to_slicing',['../namespaceep__bolfi_1_1utility_1_1dataset__formatting.html#aa63f8f724eca38294bb2aaeb7166504a',1,'ep_bolfi::utility::dataset_formatting']]]
];
