var searchData=
[
  ['n_5fcells_194',['n_cells',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#aee474f85ec3c565cea57a7d3d3243c97',1,'ep_bolfi::models::standard_parameters']]],
  ['n_5felectrodes_5fparallel_195',['n_electrodes_parallel',['../namespaceep__bolfi_1_1models_1_1standard__parameters.html#a9fc6fac6ec597239d587a46df4ebb1c6',1,'ep_bolfi::models::standard_parameters']]],
  ['ndarrayencoder_196',['NDArrayEncoder',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1NDArrayEncoder.html',1,'ep_bolfi.optimization.EP_BOLFI.NDArrayEncoder'],['../classep__bolfi_1_1utility_1_1fitting__functions_1_1NDArrayEncoder.html',1,'ep_bolfi.utility.fitting_functions.NDArrayEncoder']]],
  ['new_5fcopy_197',['new_copy',['../classep__bolfi_1_1models_1_1electrolyte_1_1Electrolyte.html#a92ead0f49af6503b33743a20822f3730',1,'ep_bolfi::models::electrolyte::Electrolyte']]],
  ['norm_5ffactor_198',['norm_factor',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Preprocessed__Simulator.html#a9c1895cf7a9470a520df34200beee508',1,'ep_bolfi::optimization::EP_BOLFI::Preprocessed_Simulator']]],
  ['normed_5fmeans_199',['normed_means',['../classep__bolfi_1_1optimization_1_1EP__BOLFI_1_1Preprocessed__Simulator.html#aa76d87665d152d264a36f7665b92f7eb',1,'ep_bolfi::optimization::EP_BOLFI::Preprocessed_Simulator']]],
  ['nyquist_5fplot_200',['nyquist_plot',['../namespaceep__bolfi_1_1utility_1_1visualization.html#a6339f95f5c841e9240873563ca04840e',1,'ep_bolfi::utility::visualization']]]
];
