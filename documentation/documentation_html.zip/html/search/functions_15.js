var searchData=
[
  ['κₑ',['κₑ',['../namespacePython_1_1models_1_1standard__parameters.html#ab8ba9bc6def9c80506915b9b4c69cb46',1,'Python::models::standard_parameters']]],
  ['κₑ_5fdim',['κₑ_dim',['../namespacePython_1_1models_1_1standard__parameters.html#a3edc608f51b82513ae6aabba05308fd9',1,'Python::models::standard_parameters']]]
];
